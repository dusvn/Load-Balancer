﻿using Common;
using LoadBalancer.DB.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadBalancer.DB.Services
{
    public class DBService
    {
        //dodavanje entiteta u bazu
        public void Add(Description d, int wid)
        {
            if(d.itemList == null)
            {
                throw new ArgumentNullException("Description nije inicijalizovan.");
            }
            else if (wid < 0)
            {
                throw new ArgumentException("Worker id ne sme biti manji od 1");
            }

            switch (d.dataSet)
            {
                case 1:
                    var db1 = new DataSet1Service();
                    foreach(Item i in d.itemList)
                    {
                        if(i.code == Code.CODE_DIGITAL)
                        {
                            string c = i.code.ToString();
                            db1.SaveDataSet(new DataSet1(c, i.value, DateTime.Now, wid));
                            //fali log upis
                            continue;
                        }

                        bool deadband = false;
                        List<DataSet1> dsList = db1.FindCodes(i.code.ToString());
                        foreach(DataSet1 ds in dsList)
                        {
                            if(Math.Abs(ds.Value - i.value) < ds.Value * 0.02)
                            {
                                deadband = true;
                                break;
                            }
                        }

                        if (!deadband)
                        {
                            string c = i.code.ToString();
                            db1.SaveDataSet(new DataSet1(c, i.value, DateTime.Now, wid));
                            //fali log upis
                        }
                    }
                    break;
                case 2:
                    var db2 = new DataSet2Service();
                    foreach (Item i in d.itemList)
                    {
                        bool deadband = false;
                        List<DataSet2> dsList = db2.FindCodes(i.code.ToString());
                        foreach (DataSet2 ds in dsList)
                        {
                            if (Math.Abs(ds.Value - i.value) < ds.Value * 0.02)
                            {
                                deadband = true;
                                break;
                            }
                        }

                        if (!deadband)
                        {
                            string c = i.code.ToString();
                            db2.SaveDataSet(new DataSet2(c, i.value, DateTime.Now, wid));
                            //fali log upis
                        }
                    }
                    break;
                case 3:
                    var db3 = new DataSet3Service();
                    foreach (Item i in d.itemList)
                    {
                        bool deadband = false;
                        List<DataSet3> dsList = db3.FindCodes(i.code.ToString());
                        foreach (DataSet3 ds in dsList)
                        {
                            if (Math.Abs(ds.Value - i.value) < ds.Value * 0.02)
                            {
                                deadband = true;
                                break;
                            }
                        }

                        if (!deadband)
                        {
                            string c = i.code.ToString();
                            db3.SaveDataSet(new DataSet3(c, i.value, DateTime.Now, wid));
                            //fali log upis
                        }
                    }
                    break;
                case 4:
                    var db4 = new DataSet4Service();
                    foreach (Item i in d.itemList)
                    {
                        bool deadband = false;
                        List<DataSet4> dsList = db4.FindCodes(i.code.ToString());
                        foreach (DataSet4 ds in dsList)
                        {
                            if (Math.Abs(ds.Value - i.value) < ds.Value * 0.02)
                            {
                                deadband = true;
                                break;
                            }
                        }

                        if (!deadband)
                        {
                            string c = i.code.ToString();
                            db4.SaveDataSet(new DataSet4(c, i.value, DateTime.Now, wid));
                            //fali log upis
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        public List<Item> GetItems(Code code, int wid, DateTime from, DateTime to)
        {
            List<Item> ret = new List<Item>();
            string c;
            if(code == Code.CODE_ANALOG || code == Code.CODE_DIGITAL)
            {
                var db1 = new DataSet1Service();
                c = code.ToString();
                List<DataSet1> dsList = db1.FindAll(c, wid, from, to);
                foreach(DataSet1 ds in dsList)
                {
                    Code cc;
                    Code.TryParse(ds.Code, out cc);
                    ret.Add(new Item(cc, ds.Value));
                }
            }
            else if (code == Code.CODE_CUSTOM || code == Code.CODE_LIMITSET)
            {
                var db2 = new DataSet2Service();
                c = code.ToString();
                List<DataSet2> dsList = db2.FindAll(c, wid, from, to);
                foreach (DataSet2 ds in dsList)
                {
                    Code cc;
                    Code.TryParse(ds.Code, out cc);
                    ret.Add(new Item(cc, ds.Value));
                }
            }
            else if (code == Code.CODE_SINGLENODE || code == Code.CODE_MULTIPLENODE)
            {
                var db3 = new DataSet3Service();
                c = code.ToString();
                List<DataSet3> dsList = db3.FindAll(c, wid, from, to);
                foreach (DataSet3 ds in dsList)
                {
                    Code cc;
                    Code.TryParse(ds.Code, out cc);
                    ret.Add(new Item(cc, ds.Value));
                }
            }
            else if (code == Code.CODE_CONSUMER || code == Code.CODE_SOURCE)
            {
                var db4 = new DataSet4Service();
                c = code.ToString();
                List<DataSet4> dsList = db4.FindAll(c, wid, from, to);
                foreach (DataSet4 ds in dsList)
                {
                    Code cc;
                    Code.TryParse(ds.Code, out cc);
                    ret.Add(new Item(cc, ds.Value));
                }
            }
            //logovanje fali
            return ret;
        }

        //brisanje svih entiteta
        public void DeleteAll()
        {
            var db1 = new DataSet1Service();
            var db2 = new DataSet2Service();
            var db3 = new DataSet3Service();
            var db4 = new DataSet4Service();
            db1.DeleteAll();
            db2.DeleteAll();
            db3.DeleteAll();
            db4.DeleteAll();
        }
    }
}

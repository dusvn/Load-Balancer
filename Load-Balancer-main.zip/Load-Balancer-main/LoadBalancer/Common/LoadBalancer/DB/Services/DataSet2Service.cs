﻿using LoadBalancer.DB.DAO;
using LoadBalancer.DB.DAO.Impl;
using LoadBalancer.DB.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadBalancer.DB.Services
{
    public class DataSet2Service
    {
        private static readonly IDataSet2DAO dataset2DAO = new DataSet2DAOimpl();

        public List<DataSet2> FindAll(string code, int wid, DateTime timefrom, DateTime timeto)
        {
            return dataset2DAO.FindAll(code, wid, timefrom, timeto).ToList();
        }

        public int SaveDataSet(DataSet2 entity)
        {
            return dataset2DAO.Save(entity);
        }

        public List<DataSet2> FindCodes(string code)
        {
            return dataset2DAO.FindCodes(code).ToList();
        }

        public int DeleteAll()
        {
            return dataset2DAO.DeleteAll();
        }
    }
}

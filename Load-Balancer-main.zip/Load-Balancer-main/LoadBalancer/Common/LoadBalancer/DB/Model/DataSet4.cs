﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadBalancer.DB.Model
{
    public class DataSet4
    {
        public string Code { get; set; }
        public int Value { get; set; }
        public DateTime Time { get; set; }
        public int Wid { get; set; }

        public DataSet4() { }
        public DataSet4(string code, int value, DateTime time, int wid)
        {
            this.Code = code;
            this.Value = value;
            this.Time = time;
            this.Wid = wid;
        }

        public override string ToString()
        {
            return string.Format("{0,-20} {1,-25} {2,-25} {3,-2}", Code, Value, Time, Wid);
        }

        public static string GetFormattedHeader()
        {
            return string.Format("{0,-20} {1,-25} {2,-25} {3,-2}",
                                "CODE", "VALUE", "TIME", "WID");
        }
    }
}

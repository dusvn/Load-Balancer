﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadBalancer.DB.DAO
{
    public interface ICRUDDao<T, ID>
    {
        int DeleteAll();

        IEnumerable<T> FindAll(string code, int wid, DateTime timefrom, DateTime timeto);

        int Save(T entity);

        IEnumerable<T> FindCodes(string code);
    }
}

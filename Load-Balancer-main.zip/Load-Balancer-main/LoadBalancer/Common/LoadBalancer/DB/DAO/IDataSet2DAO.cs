﻿using LoadBalancer.DB.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadBalancer.DB.DAO
{
    public interface IDataSet2DAO : ICRUDDao<DataSet2, int>
    {

    }
}

﻿using LoadBalancer.DB.Connection;
using LoadBalancer.DB.Model;
using LoadBalancer.DB.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadBalancer.DB.DAO.Impl
{
    public class DataSet3DAOimpl : IDataSet3DAO
    {
        public IEnumerable<DataSet3> FindAll(string code, int wid, DateTime timefrom, DateTime timeto)
        {
            string query = "select code, value, time, wid from dataset3 " +
                "where time between :timefrom and :timeto " +
                "and wid = :wid " +
                "and code = :code";

            List<DataSet3> dataset3List = new List<DataSet3>();

            using (IDbConnection connection = ConnectionUtil_Pooling.GetConnection())
            {
                connection.Open();
                using (IDbCommand command = connection.CreateCommand())
                {
                    command.CommandText = query;
                    ParameterUtil.AddParameter(command, "timefrom", DbType.DateTime);
                    ParameterUtil.AddParameter(command, "timeto", DbType.DateTime);
                    ParameterUtil.AddParameter(command, "wid", DbType.Int32);
                    ParameterUtil.AddParameter(command, "code", DbType.String);
                    ParameterUtil.SetParameterValue(command, "timefrom", timefrom);
                    ParameterUtil.SetParameterValue(command, "timeto", timeto);
                    ParameterUtil.SetParameterValue(command, "wid", wid);
                    ParameterUtil.SetParameterValue(command, "code", code);
                    command.Prepare();

                    using (IDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            DataSet3 ds = new DataSet3(reader.GetString(0), reader.GetInt32(1), reader.GetDateTime(2), reader.GetInt32(3));
                            dataset3List.Add(ds);
                        }
                    }
                }
            }

            return dataset3List;
        }

        public IEnumerable<DataSet3> FindCodes(string code)
        {
            string query = "select code, value, time, wid from dataset3 " +
                "where code = :code";

            List<DataSet3> dataset3List = new List<DataSet3>();

            using (IDbConnection connection = ConnectionUtil_Pooling.GetConnection())
            {
                connection.Open();
                using (IDbCommand command = connection.CreateCommand())
                {
                    command.CommandText = query;
                    ParameterUtil.AddParameter(command, "code", DbType.String);
                    ParameterUtil.SetParameterValue(command, "code", code);
                    command.Prepare();

                    using (IDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            DataSet3 ds = new DataSet3(reader.GetString(0), reader.GetInt32(1), reader.GetDateTime(2), reader.GetInt32(3));
                            dataset3List.Add(ds);
                        }
                    }
                }
            }

            return dataset3List;
        }

        public int Save(DataSet3 entity)
        {
            using (IDbConnection connection = ConnectionUtil_Pooling.GetConnection())
            {
                connection.Open();

                String insertSql = "insert into dataset3 " +
                "values (:code, :value, :time, :wid)";


                using (IDbCommand command = connection.CreateCommand())
                {
                    command.CommandText = insertSql;
                    ParameterUtil.AddParameter(command, "code", DbType.String);
                    ParameterUtil.AddParameter(command, "value", DbType.Int32);
                    ParameterUtil.AddParameter(command, "time", DbType.DateTime);
                    ParameterUtil.AddParameter(command, "wid", DbType.Int32);
                    ParameterUtil.SetParameterValue(command, "code", entity.Code);
                    ParameterUtil.SetParameterValue(command, "value", entity.Value);
                    ParameterUtil.SetParameterValue(command, "time", entity.Time);
                    ParameterUtil.SetParameterValue(command, "wid", entity.Wid);
                    return command.ExecuteNonQuery();
                }
            }
        }

        public int DeleteAll()
        {
            string query = "delete from dataset3";

            using (IDbConnection connection = ConnectionUtil_Pooling.GetConnection())
            {
                connection.Open();
                using (IDbCommand command = connection.CreateCommand())
                {
                    command.CommandText = query;
                    command.Prepare();
                    return command.ExecuteNonQuery();
                }
            }

        }
    }
}

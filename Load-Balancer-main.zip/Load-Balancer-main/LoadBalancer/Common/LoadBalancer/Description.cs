﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadBalancer
{
    public class Description
    {
        public uint id { get; }
        public List<Item> itemList { get; set; }
        public int dataSet { get; }
        private static uint count = 0;

        public Description(int ds)
        {
            if (ds < 1 || ds > 4)
            {
                throw new ArgumentException("Argument ne sme biti veci od 4 ili manji od 1");
            }
            else
            {
                id = ++count;
                itemList = new List<Item>();
                dataSet = ds;
            }
        }

        public void Add(Item item)
        {
            itemList.Add(item);
        }
    }
}
